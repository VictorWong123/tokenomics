# Controller development measurements

Bounded, frozen development engineering comparison; uncertainty resamples distinct prompts, not repetitions. No full Pilot A/B or 90-prompt held-out result.

Frozen fixed comparator: `fixed1`. Synthetic fixtures: `False`.

| Policy | Decode tokens/s¹ | Median warm ms | Peak RSS MiB | Decision + update / generation |
|---|---:|---:|---:|---:|
| acceptance | 106.255 | 1050.03 | 645.9 | 0.002% |
| cost-aware | 106.617 | 1039.69 | 646.1 | 0.004% |
| dynamic | 94.693 | 1299.50 | 647.4 | 0.001% |
| fixed1 | 108.684 | 1069.51 | 642.1 | 0.001% |
| no-fallback | 101.502 | 1187.08 | 645.0 | 0.005% |
| no-probes | 103.672 | 1102.68 | 642.2 | 0.004% |
| target | 116.000 | 1024.64 | 640.2 | 0.001% |

¹ Geometric mean of prompt/cap median throughput. Full probe, synchronization and update work remains charged. RSS is lifetime process peak, not policy memory savings.

| Comparison | Throughput ratio | Prompt-bootstrap 95% interval |
|---|---:|---:|
| cost-aware/target | 0.9191 | [0.8524, 0.9780] |
| cost-aware/fixed1 | 0.9810 | [0.9238, 1.0368] |
| cost-aware/dynamic | 1.1259 | [1.0016, 1.2723] |
| cost-aware/acceptance | 1.0034 | [0.9332, 1.0687] |
| cost-aware/cost-aware | 1.0000 | [1.0000, 1.0000] |
