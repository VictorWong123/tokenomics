# Controller development measurements

Bounded, frozen development engineering comparison; uncertainty resamples distinct prompts, not repetitions. No full Pilot A/B or 90-prompt held-out result.

Frozen fixed comparator: `fixed1`. Synthetic fixtures: `False`.

| Policy | Decode tokens/s¹ | Median warm ms | Peak RSS MiB | Decision + update / generation |
|---|---:|---:|---:|---:|
| cost-aware | 120.397 | 1086.78 | 631.9 | 0.004% |
| cost-aware-detailed | 99.583 | 1287.67 | 632.0 | 0.007% |
| fixed1 | 113.304 | 1202.40 | 633.7 | 0.002% |
| target | 115.616 | 1120.69 | 627.3 | 0.001% |

¹ Geometric mean of prompt/cap median throughput. Full probe, synchronization and update work remains charged. RSS is lifetime process peak, not policy memory savings.

| Comparison | Throughput ratio | Prompt-bootstrap 95% interval |
|---|---:|---:|
| cost-aware/target | 1.0414 | [0.9527, 1.1383] |
| cost-aware/fixed1 | 1.0626 | [1.0495, 1.0759] |
| cost-aware/cost-aware | 1.0000 | [1.0000, 1.0000] |
